//
//  Token.swift
//  ClientsList
//
//  Created by Konstantin Khokhlov on 07.07.17.
//  Copyright © 2017 Konstantin Khokhlov. All rights reserved.
//

import Foundation

struct Token {
    let id: String
}
